Entity.Find("enemy1").Get<AircraftComponent>().Armor = 0;
Entity.Find("enemy2").Get<AircraftComponent>().Armor = 0;
Entity.Find("enemy3").Get<AircraftComponent>().Armor = 0;